//
//  ConsultCollectionViewCell.swift
//  MiniProject
//
//  Created by zehye on 2021/11/12.
//

import UIKit

class ConsultCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var titleLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
