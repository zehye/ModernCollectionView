//
//  ModelComplexExpert.swift
//  MiniProject
//
//  Created by zehye on 2021/11/10.
//

import UIKit

//class ModelComplexExpert: Codable {
//    var companyInfo: ModelCompany?
//    var expertInfo: ModelExpert?
////    var forClientInfo: ExpertForClientInfoDTO?
////    var subjectList = [SubjectResponseDTO]()
////    var tagList = [TagResponseDTO]()
//}
